const body = document.querySelector('body');
const cadetGray = 'rgb(154, 160, 168)';
const ashGray = 'rgb(167, 196, 181)';
const celadon = 'rgb(169, 216, 136)';
const teaGreen = 'rgb(190, 255, 199)';
const resedaGreen = 'rgb(114, 112, 91)';
const white = 'rgb(255, 255, 255)';
const blue = 'rgb(56, 83, 128)';
const orange = 'rgb(207, 129, 21)';
const pink = 'rgb(156, 72, 111)';
const purple = 'rgb(156, 72, 156)';
const listOfColors = [white, cadetGray, ashGray, celadon, teaGreen, resedaGreen, blue, orange, pink, purple];
const btn = document.querySelector('#btn');

btn.addEventListener('click', () => {
    let randomIndex = Math.floor(Math.random() * listOfColors.length);
    body.style.backgroundColor = listOfColors[randomIndex];
});
